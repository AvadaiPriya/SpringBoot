package com.example.demos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosApplicationTests {

	@Test
	void contextLoads() {
	}

}
