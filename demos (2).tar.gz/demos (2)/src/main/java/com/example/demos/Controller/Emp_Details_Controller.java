package com.example.demos.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demos.DAO.Emp_Details_DAO;
import com.example.demos.Emp_Details.Emp_Details;
import com.example.demos.Service.Emp_Details_service;


@RestController
@RequestMapping("Employee")
public class Emp_Details_Controller {

	@Autowired
	public Emp_Details_service dao;

	@RequestMapping("/getEmp_Details")
	public List<Emp_Details> list() {
		return dao.list();
	}
	
	@PostMapping("/add") 
	public Emp_Details addEmployee(@RequestBody Emp_Details emp_details) {
		
	
		dao.addEmployee(emp_details);
		return emp_details;
		
	}
	
	@RequestMapping(value = "/getEmp_Details/{Emp_id}", method = RequestMethod.POST)
	public Emp_Details emp_details(@PathVariable int Emp_id) {
		
		Emp_Details emp_details=dao.find(Emp_id);
		
		if(emp_details==null) {
			
			throw new RuntimeException();
		}
		return emp_details;
	}
	
	@DeleteMapping("/getEmp_Details/{Emp_id}")
	public String Delete(@PathVariable int Emp_id) {
		
		Emp_Details emp_details=dao.find(Emp_id);
		
		if(emp_details==null) {
			throw new RuntimeException();
		}
		dao.delete(Emp_id);
		return "Deleted employee id=" +Emp_id;
	}

}