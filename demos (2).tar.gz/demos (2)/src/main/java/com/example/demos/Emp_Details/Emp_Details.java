package com.example.demos.Emp_Details;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


public class Emp_Details {

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int Emp_id;
	private int Project_id;
	

    public Emp_Details() {
    }

	public Emp_Details(int id, int project_id) {
	
		this.Emp_id = id;
		this.Project_id = project_id;
	}

	public int getId() {
		return Emp_id;
	}

	public void setId(int id) {
		this.Emp_id = id;
	}

	public int getProject_id() {
		return Project_id;
	}

	public void setProject_id(int project_id) {
		this.Project_id = project_id;
	}

  
}
