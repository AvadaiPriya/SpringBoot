package com.example.demos.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.demos.Emp_Details.Emp_Details;



@Repository
public class Emp_Details_DAO_impl implements Emp_Details_DAO {

	
	@Autowired
	private JdbcTemplate jdbcTemplate;


	public List<Emp_Details> list() {
		final String SQL = "select * from Emp_Details";
		return jdbcTemplate.query(SQL, new RowMapper<Emp_Details>() {

			@Override
			public Emp_Details mapRow(ResultSet rs, int arg1) throws SQLException {
				Emp_Details p = new Emp_Details();
				p.setId(rs.getInt("Emp_id"));
				p.setProject_id(rs.getInt("project_id"));
				return p;
			}

		});
	}



	@Override
	public int addEmployee(Emp_Details emp_details) {
		System.out.print(emp_details.getProject_id());
		String sql="insert into Emp_Details(Project_id)values("+emp_details.getProject_id() +")";
		return jdbcTemplate.update(sql);
		
	}



	@Override
	public Emp_Details find(int id) {
		String sql="select * from Emp_Details where Emp_id=?";
		return jdbcTemplate.queryForObject(sql,new Object[]{id},new RowMapper<Emp_Details>() {

			@Override
			public Emp_Details mapRow(ResultSet rs, int arg1) throws SQLException {
				Emp_Details p = new Emp_Details();
				p.setId(rs.getInt("Emp_id"));
				p.setProject_id(rs.getInt("project_id"));
				return p;
			}

		});
		
		
	}



	@Override
	public void delete(int id) {
		String sql="Delete from Emp_Details  where Emp_id=?";
		jdbcTemplate.update(sql, id);
	      System.out.println("Deleted Record with ID = " + id );
	      return;
		
	}
}
