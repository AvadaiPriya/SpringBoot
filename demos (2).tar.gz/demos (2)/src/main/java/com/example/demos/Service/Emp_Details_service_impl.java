package com.example.demos.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demos.DAO.Emp_Details_DAO;
import com.example.demos.Emp_Details.Emp_Details;

@Service
public class Emp_Details_service_impl implements Emp_Details_service {
	
	

	@Autowired
	public Emp_Details_DAO dao;

	@Override
	public List<Emp_Details> list() {

		return dao.list();
	}

	@Override
	public int addEmployee(Emp_Details emp_details) {
		
		return  dao.addEmployee(emp_details);
	}

	@Override
	public Emp_Details find(int id) {
			 
		return dao.find(id);
		
	}

	@Override
	public void delete(int id) {
		dao.delete(id);
		
	}


}
