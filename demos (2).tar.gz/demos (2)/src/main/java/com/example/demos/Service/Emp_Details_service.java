package com.example.demos.Service;

import java.util.List;

import com.example.demos.DAO.Emp_Details_DAO;
import com.example.demos.DAO.Emp_Details_DAO_impl;
import com.example.demos.Emp_Details.Emp_Details;

public interface Emp_Details_service {

	
	public List<Emp_Details> list();
	public int addEmployee(Emp_Details emp_details);
	public Emp_Details find(int id);
	public void delete(int id);
}
